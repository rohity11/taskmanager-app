# task_manager/signals.py
from django.contrib import messages
from django.dispatch import receiver
from allauth.account.signals import user_logged_in
from django.contrib.auth.models import User

@receiver(user_logged_in)
def user_logged_in_handler(sender, request, user, **kwargs):
    messages.success(request, f"Welcome, {user.username}! You have successfully logged in.")
