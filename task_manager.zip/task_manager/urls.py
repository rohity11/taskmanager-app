from django.urls import path,include
from . import views

urlpatterns = [
    path('', views.home, name='home'),
     path('accounts/', include('allauth.urls')),  # This includes all the auth-related URLs (login, logout, etc.)
    
    path('task/create/', views.create_task, name='create_task'),
    path('task/<int:pk>/', views.task_detail, name='task_detail'),
    path('task/<int:pk>/edit/', views.edit_task, name='edit_task'),
    path('task/<int:pk>/delete/', views.delete_task, name='delete_task'),
]
