from django.shortcuts import render, redirect
from .models import Task
from .forms import TaskForm


# Home page
def home(request):
    tasks = Task.objects.filter(user=request.user)
    return render(request, 'task_manager/task_list.html', {'tasks': tasks})

# Task Detail Page
def task_detail(request, pk):
    task = Task.objects.get(pk=pk)
    return render(request, 'task_manager/task_detail.html', {'task': task})

# Create Task
def create_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.user = request.user
            task.save()
            return redirect('home')
    else:
        form = TaskForm()
    return render(request, 'task_manager/task_form.html', {'form': form})

# Edit Task
def edit_task(request, pk):
    task = Task.objects.get(pk=pk)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = TaskForm(instance=task)
    return render(request, 'task_manager/task_form.html', {'form': form})

# Delete Task
def delete_task(request, pk):
    task = Task.objects.get(pk=pk)
    task.delete()
    return redirect('home')



# Home Page: List all tasks of logged-in user
def home(request):
    if not request.user.is_authenticated:
        return redirect('account_login')  # Redirect to login if not authenticated

    tasks = Task.objects.filter(user=request.user)
    return render(request, 'task_manager/task_list.html', {'tasks': tasks})

